"""
Alembic migration environment.
Reads the database URL from .env via our config module.
Imports all models so Alembic can autogenerate migrations.
"""
import sys
import os
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context

# ── Make project root importable ──────────────────────────────
# This file lives at backend/db/migrations/env.py
# Project root is 3 levels up
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))

# ── Import config and all models ──────────────────────────────
from backend.shared.config import settings
from backend.db.base import Base
from backend.db import models  # noqa: F401 — must import so Alembic sees all tables

# ── Alembic config ────────────────────────────────────────────
config = context.config

# Inject the real database URL (from .env) into Alembic config
config.set_main_option("sqlalchemy.url", settings.database_url)

# Set up Python logging from the alembic.ini [loggers] section
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# The metadata Alembic will compare against the DB to generate migrations
target_metadata = Base.metadata


# ── Migration runners ─────────────────────────────────────────
def run_migrations_offline() -> None:
    """
    Run migrations without a live DB connection.
    Generates SQL scripts you can review before applying.
    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """
    Run migrations against the live database.
    This is what `alembic upgrade head` uses.
    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
